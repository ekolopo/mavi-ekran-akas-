tr

gerçek bir mavi ekran değildir alt f4 ile çıkabilirsiniz dahada gerçekçi olmasını istiyorsanız destek olabilirsiniz virüs değildir kodlara baka bilirsin


ABD
It is not a real blue screen. You can exit with Alt+F4. If you want it to be more realistic, you can support it. It is not a virus. You can look at the code.