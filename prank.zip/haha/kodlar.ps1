Add-Type -AssemblyName PresentationFramework,PresentationCore,WindowsBase

# Pencere oluştur
$Window = New-Object Windows.Window
$Window.WindowStyle = 'None'
$Window.WindowState = 'Maximized'
$Window.ResizeMode = 'NoResize'
$Window.Background = 'DarkBlue'
$Window.Topmost = $true

# Panel
$Stack = New-Object Windows.Controls.StackPanel
$Stack.Margin = 100

# :( yüzü
$Sad = New-Object Windows.Controls.TextBlock
$Sad.Text = ":("
$Sad.FontSize = 140
$Sad.Foreground = 'White'
$Stack.Children.Add($Sad)

# Mesaj
$Msg = New-Object Windows.Controls.TextBlock
$Msg.Text = "Your PC run into a problem and needs to restart."
$Msg.FontSize = 30
$Msg.Foreground = 'White'
$Msg.Margin = "0,30,0,0"
$Stack.Children.Add($Msg)

$Msg2 = New-Object Windows.Controls.TextBlock
$Msg2.Text = "We're just collecting some error info, and then we'll restart for you."
$Msg2.FontSize = 20
$Msg2.Foreground = 'White'
$Stack.Children.Add($Msg2)

# % ilerleme
$Pct = New-Object Windows.Controls.TextBlock
$Pct.FontSize = 24
$Pct.Foreground = 'White'
$Pct.Margin = "0,20,0,0"
$Stack.Children.Add($Pct)

# QR kod (ASCII benzeri)
$QR = New-Object Windows.Controls.TextBlock
$QR.Text = @"

"@
$QR.FontFamily = "Consolas"
$QR.FontSize = 14
$QR.Foreground = 'White'
$QR.Margin = "0,40,0,0"
$Stack.Children.Add($QR)

# Stop code
$Stop = New-Object Windows.Controls.TextBlock
$Stop.Text = "For more information about this issue and possible fixes, visit https://www.windows.com/stopcode`n`nIf you call a support person, give them this info:`nStop code: (10000 dolar pay now)"
$Stop.FontSize = 18
$Stop.Foreground = 'White'
$Stop.Margin = "0,30,0,0"
$Stack.Children.Add($Stop)

$Window.Content = $Stack

# % sayacı
$Progress = 0
$Timer = New-Object Windows.Threading.DispatcherTimer
$Timer.Interval = [TimeSpan]"0:0:0.1"
$Timer.Add_Tick({
    if ($Progress -lt 100) {
        $Progress++
        $Pct.Text = "$Progress% complete"
    }
})
$Timer.Start()

# ESC ile çıkış
$Window.Add_KeyDown({
    if ($_.Key -eq 'Escape') { $Window.Close() }
})

$Window.ShowDialog() | Out-Null
